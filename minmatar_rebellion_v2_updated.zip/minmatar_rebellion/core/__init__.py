# Core module - contains core utilities and loaders
