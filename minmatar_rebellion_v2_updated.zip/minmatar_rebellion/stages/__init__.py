# Stages module - contains stage classes and definitions
