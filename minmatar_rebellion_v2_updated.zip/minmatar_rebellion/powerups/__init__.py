# Powerups module - contains power-up classes and definitions
